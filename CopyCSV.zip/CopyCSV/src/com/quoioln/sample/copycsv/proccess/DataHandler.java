package com.quoioln.sample.copycsv.proccess;

import com.google.common.collect.Iterators;
import com.quoioln.sample.copycsv.model.CheckRecord;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;

import com.quoioln.sample.copycsv.utils.Utils;
import java.io.File;
import javax.swing.JProgressBar;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;

/**
 * The Class DataHandler.
 */
public class DataHandler {

    private File spcFile = null;
    private File ctoFile = null;
    private String resultFile = null;
    
    private final String FONT_NAME = "Times New Roman";
    private final short FONT_SIZE = 280;
//    private JProgressBar pgbCopy = null;

    /**
     * The constructor
     *
     * @param spcFile
     * @param ctoFile
     * @param resultPath
     */
    public DataHandler(File spcFile, File ctoFile, String resultPath) {
        this.spcFile = spcFile;
        this.ctoFile = ctoFile;
        this.resultFile = resultPath;
        System.out.println(resultPath);
    }

    /**
     * Insert record.
     *
     * @param pgbCopy
     */
    public void insertRecord(JProgressBar pgbCopy) throws Exception {
        try {
            // Load SPC.xls and CTO.xls
            FileInputStream spcFile = new FileInputStream(this.spcFile);
            FileInputStream ctoFile = new FileInputStream(this.ctoFile);

            HSSFWorkbook spcWorkbook = new HSSFWorkbook(spcFile);
            HSSFWorkbook ctoWorkbook = new HSSFWorkbook(ctoFile);
            
            HSSFSheet resultSheet = spcWorkbook.getSheetAt(0);
            HSSFSheet ctoSheet = ctoWorkbook.getSheetAt(0);

            HSSFSheet spcSheet = spcWorkbook.cloneSheet(0);
            Iterator<Row> ctoRowsListTemp = ctoSheet.iterator();
            Iterator<Row> ctoRowsList = ctoSheet.iterator();

            if (!ctoRowsList.hasNext()) {
                spcWorkbook.close();
                ctoWorkbook.close();
                spcFile.close();
                ctoFile.close();
                return;
            }
            // pass header
            ctoRowsList.next();
            // row start copy
            // int rowStartCopy = spcRowsList.
            int lastSPCRow = spcSheet.getLastRowNum();

            // Create cell style alert from SPC
            CellStyle cellStyleNormal = spcSheet.getColumnStyle(0);
            Font fontNormal = spcWorkbook.createFont();
            Utils.setFontProperties(fontNormal, FONT_NAME, FONT_SIZE, IndexedColors.BLACK.index);
            
            // create cell style SPC alert duplicate
            CellStyle cellStyleSPCAlertDuplicate = spcWorkbook.createCellStyle();
            cellStyleSPCAlertDuplicate.cloneStyleFrom(cellStyleNormal);
            
            cellStyleSPCAlertDuplicate.setFillForegroundColor(IndexedColors.YELLOW.index);
            cellStyleSPCAlertDuplicate.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            Font fontAlertDuplicate = spcWorkbook.createFont();
            Utils.setFontProperties(fontAlertDuplicate, FONT_NAME, FONT_SIZE, IndexedColors.BLUE.index);
            cellStyleSPCAlertDuplicate.setFont(fontAlertDuplicate);
            
            
            // create cell style SPC alert duplicate
            CellStyle cellStyleSPCAlertInvalid = spcWorkbook.createCellStyle();
            cellStyleSPCAlertInvalid.cloneStyleFrom(cellStyleSPCAlertDuplicate);
            Font fontAlertInvalid = spcWorkbook.createFont();
            Utils.setFontProperties(fontAlertInvalid, FONT_NAME, FONT_SIZE, IndexedColors.RED.index);
            cellStyleSPCAlertInvalid.setFont(fontAlertInvalid);
            
            Row ctoRow = null;
            Cell ctoCell = null;

            int totalRow = Iterators.size(ctoRowsListTemp) - 1;
            DataFormatter formatter = new DataFormatter();
            int currentRow = 0;

            while (ctoRowsList.hasNext()) {
                Iterator<Row> spcRowsList = spcSheet.iterator();
                int columnNumber = 0;
                ctoRow = ctoRowsList.next();

                // Create new row spc
                Row newSPCRow = resultSheet.createRow(++lastSPCRow);

                int newNumberColumn = 0;
                CheckRecord checkRecord = Utils.checkRecord(ctoRow, spcRowsList);
                // Create cell style corresponding
                CellStyle cellStyle = null;
                if (CheckRecord.DUPLICATE == checkRecord.getStatusCode()) {
                    cellStyle = cellStyleSPCAlertDuplicate;
                } else if (CheckRecord.INVALID == checkRecord.getStatusCode()) {
                    cellStyle = cellStyleSPCAlertInvalid;
                } else {
                    cellStyle = cellStyleNormal;
                }
                
                Iterator<Cell> ctoCellList = ctoRow.iterator();
                while (ctoCellList.hasNext()) {
                    ctoCell = ctoCellList.next();
                    columnNumber++;
                    if (columnNumber == 1) {
                        continue;
                    }
                    if (columnNumber > 4) {
                        break;
                    }

                    Cell newSPCCell = newSPCRow.createCell(newNumberColumn++);
                    String value = formatter.formatCellValue(ctoCell);
                    newSPCCell.setCellValue(value);
                    newSPCCell.setCellStyle(cellStyle);
                }
                if (CheckRecord.NO_ERROR != checkRecord.getStatusCode()) {
                    Cell newSPCCell = newSPCRow.createCell(newNumberColumn++);
                    newSPCCell.setCellValue(checkRecord.getMessage());
                    newSPCCell.setCellStyle(cellStyle);
                }
                currentRow++;

                int percent = (currentRow * 100) / totalRow;
                pgbCopy.setValue(percent);
//                pgbCopy.update(pgbCopy.getGraphics());
            }
            resultSheet.autoSizeColumn(3);
            FileOutputStream fileResult = new FileOutputStream(resultFile);

            spcWorkbook.removeSheetAt(1);
            spcWorkbook.write(fileResult);

            spcWorkbook.close();
            ctoWorkbook.close();
            fileResult.close();
            spcFile.close();
            ctoFile.close();
        } catch (IOException e) {
            throw new Exception();
        }
    }
}
