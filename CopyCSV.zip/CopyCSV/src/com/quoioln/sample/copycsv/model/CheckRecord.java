package com.quoioln.sample.copycsv.model;

public class CheckRecord {
        
        public static final int NO_ERROR = 0;
        
        public static final int DUPLICATE = 1;
        
        public static final int INVALID = 2;
    
	private String message;
	
	private int statusCode;
	
	
	
	/**
	 * The constructor
	 * @param message
	 * @param success
	 */
	public CheckRecord(String message, int success) {
		this.message = message;
		this.statusCode = success;
	}
	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

    /**
     * @return the statusCode
     */
    public int getStatusCode() {
        return statusCode;
    }

    /**
     * @param statusCode the statusCode to set
     */
    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }
}
