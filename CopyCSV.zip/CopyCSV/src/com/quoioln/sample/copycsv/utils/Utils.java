/**
 * 
 */
package com.quoioln.sample.copycsv.utils;

import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;

import com.quoioln.sample.copycsv.model.CheckRecord;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;

/**
 * @author Quoi Vo
 *
 */
public class Utils {

    private final static int MA_VT_SPC = 0;

    private final static int TEN_SPC = 1;

    private static final DataFormatter dataFormatter = new DataFormatter();
    
    private static final int MAX_LENGTH = 50;

    public static CheckRecord checkRecord(Row row, Iterator<Row> spcRowList) {
        CheckRecord checkRecord = new CheckRecord("success", CheckRecord.NO_ERROR);
        if (!spcRowList.hasNext()) {
            return checkRecord;
        }
        // skip header spc
        spcRowList.next();
        Row spcRow = null;

        Cell maVtSPCCell = null;
        Cell tenSPCCell = null;

        String mvVtSPCCheck = dataFormatter.formatCellValue(row.getCell(MA_VT_SPC + 1));
        String tenSPCCheck = dataFormatter.formatCellValue(row.getCell(TEN_SPC + 1));
        int line = 0;
        
        while (spcRowList.hasNext()) {
            line++;
            spcRow = spcRowList.next();
            maVtSPCCell = spcRow.getCell(MA_VT_SPC);
            tenSPCCell = spcRow.getCell(TEN_SPC);
            // Get mvVtSPC, tenSPC from SPC row
            String mvVtSPC = dataFormatter.formatCellValue(maVtSPCCell);
            String tenSPC = dataFormatter.formatCellValue(tenSPCCell);
            if (mvVtSPCCheck.equals(mvVtSPC)) {
                if (tenSPCCheck.equals(tenSPC)) {
                    checkRecord.setMessage(createMeassage(mvVtSPCCheck, true, line));
                    checkRecord.setStatusCode(CheckRecord.DUPLICATE);
                } else {
                    checkRecord.setMessage(createMeassage(mvVtSPCCheck, false, line));
                    checkRecord.setStatusCode(CheckRecord.INVALID);
                }
                
            }
        }
        return checkRecord;
    }

    private static String createMeassage(String mvVtSPCCheck, boolean isDuplicate, int line) {
        StringBuilder meassage = new StringBuilder();
        if (isDuplicate) {
            meassage.append("MAVTSPC ").append(mvVtSPCCheck).append(" đã tồn tại ở dòng ").append(line);
        } else {
            meassage.append("TENSPC ").append(" khác so với dòng ").append(line);
        }

        return meassage.toString();
    }
    
    public static String cutFilePath(String filePath) {
        int length = filePath.length();
        if (length > MAX_LENGTH) {
            int indexCut = length - MAX_LENGTH;
            filePath = filePath.substring(indexCut);
            filePath = "..." + filePath;
        }
        return filePath;
    }
    
    public static void setFontProperties(Font font, final String fontName, final short fontSize, final short color) {
        font.setFontName(fontName);
        font.setFontHeight(fontSize);
        font.setColor(color);
    }
}

